<?php

if (empty($_POST['name'])) {

// display error message (Name is empty)
echo "<script type='text/javascript'>
alert('Error: Please enter the Hotel Name.');
history.go(-1);
</script>";
}

else if (isset ($_POST['description']) == false || empty($_POST['description'])) {

// display error message (Price is empty)
echo "<script type='text/javascript'>
alert('Error: Please enter the Description.');
history.go(-1);
</script>";
}

else if (isset ($_POST['location']) == false || empty($_POST['location'])) {

// display error message (Location is empty)
echo "<script type='text/javascript'>
alert('Error: Please enter the Location.');
history.go(-1);
</script>";
}


else if (isset ($_POST['price']) == false || empty($_POST['price'])) {

// display error message (Price is empty)
echo "<script type='text/javascript'>
alert('Error: Please enter the Price.');
history.go(-1);
</script>";
}


else if (isset ($_POST['profit']) == false || empty($_POST['profit'])) {

// display error message (Profit is empty)
echo "<script type='text/javascript'>
alert('Error: Please enter the Profit.');
history.go(-1);
</script>";
}
else if (isset ($_POST['stockBalance']) == false || empty($_POST['stockBalance'])) {

// display error message (stockBalance is empty)
echo "<script type='text/javascript'>
alert('Error: Please enter the Stock Balance.');
history.go(-1);
</script>";
}

else if (empty($_FILES["fileToUpload"]["name"])) {

// display error message (File is empty)
echo "<script type='text/javascript'>
alert('Error: Please upload the Image.');
history.go(-1);
</script>";
}
else {




if ($places['category'] == "Penang") {
echo "<option value='Penang' selected>Penang</option>";
} else {
echo "<option value='Penang'>Penang</option>";
}

if  ($places['category'] == "Negeri Sembilan") {
echo "<option value='Negeri Sembilan' selected='selected'>Negeri Sembilan</option>";
} else {
echo "<option value='Negeri Sembilan'>Negeri Sembilan</option>";
}

if  ($places['category'] == "Perak") {
echo "<option value='Perak' selected>Perak</option>";
} else {
echo "<option value='Perak'>Perak</option>";
}

if  ($places['category'] == "Johor") {
echo "<option value='Johor' selected>Johor</option>";
} else {
echo "<option value='Johor'>Johor</option>";
}

if  ($places['category'] == "Kedah") {
echo "<option value='Kedah' selected>Kedah</option>";
} else {
echo "<option value='Kedah'>Kedah</option>";
}

if  ($places['category'] == "Kelantan") {
echo "<option value='Kelantan' selected>Kelantan</option>";
} else {
echo "<option value='Kelantan'>Kelantan</option>";
}

if  ($places['category'] == "Malacca") {
echo "<option value='Malacca' selected>Malacca</option>";
} else {
echo "<option value='Malacca'>Malacca</option>";
}

if  ($places['category'] == "Pahang") {
echo "<option value='Pahang' selected>Pahang</option>";
} else {
echo "<option value='Pahang'>Pahang</option>";
}

if  ($places['category'] == "Perlis") {
echo "<option value='Perlis' selected>Perlis</option>";
} else {
echo "<option value='Perlis'>Perlis</option>";
}

if  ($places['category'] == "Sabah") {
echo "<option value='Sabah' selected>Sabah</option>";
} else {
echo "<option value='Sabah'>Sabah</option>";
}

if  ($places['category'] == "Sarawak") {
echo "<option value='Sarawak' selected>Sarawak</option>";
} else {
echo "<option value='Sarawak'>Sarawak</option>";
}

if  ($places['category'] == "Selangor") {
echo "<option value='Selangor' selected>Selangor</option>";
} else {
echo "<option value='Selangor'>Selangor</option>";
}


if  ($places['category'] == "Terengganu") {
echo "<option value='Terengganu' selected>Terengganu</option>";
} else {
echo "<option value='Terengganu'>Terengganu</option>";
}



if ($places['rating'] == "5") {
echo "<option value='5' selected>5</option>";
} else {
echo "<option value='5'>5</option>";
}

if  ($places['rating'] == "4") {
echo "<option value='4' selected='selected'>4</option>";
} else {
echo "<option value='4'>4</option>";
}

if  ($places['rating'] == "3") {
echo "<option value='3' selected>3</option>";
} else {
echo "<option value='3'>3</option>";
}

if  ($places['rating'] == "2") {
echo "<option value='2' selected>2</option>";
} else {
echo "<option value='2'>2</option>";
}

if  ($places['rating'] == "1") {
echo "<option value='1' selected>1</option>";
} else {
echo "<option value='1'>1</option>";
}



if ($places['rooms'] == "Single Room") {
echo "<option value='Single Room' selected>Single Room</option>";
} else {
echo "<option value='Single Room'>Single Room</option>";
}

if  ($places['rooms'] == "Double Bedroom") {
echo "<option value='Double Bedroom' selected='selected'>Double Bedroom</option>";
} else {
echo "<option value='Double Bedroom'>Double Bedroom</option>";
}

if  ($places['rooms'] == "Large Bedroom") {
echo "<option value='Large Bedroom' selected>Large Bedroom</option>";
} else {
echo "<option value='Large Bedroom'>Large Bedroom</option>";
}




$target_dir = "images/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
if($check !== false) {
echo "File is an image - " . $check["mime"] . ".";
$uploadOk = 1;
} else {
echo "File is not an image.";
$uploadOk = 0;
}
}
// Check if file already exists
if (file_exists($target_file)) {
echo "Sorry, file already exists.";
$uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
echo "Sorry, your file is too large.";
$uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
$uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
} else {
echo "Sorry, there was an error uploading your file.";
}
}

//Connect mySQL
$connection = mysqli_connect('localhost','root','','places');

//Select Database
mysqli_select_db($connection, 'destination');

$name = $_POST["name"];
$category = $_POST["category"];
$price = $_POST["price"];
$rooms = $_POST["rooms"];
$stockBalance = $_POST["stockBalance"];
$profit = $_POST["profit"];
$rating = $_POST["rating"];
$location = $_POST["location"];

$description = $_POST["description"];
$image = $target_file;

//Insert Query 
$sql = "INSERT INTO destination (Name,Category,Rooms ,Price,Profit ,Rating,StockBalance,Description,Location ,Image)
 VALUES('$name','$category','$rooms','$price','$profit','$rating','$stockBalance','$description','$location','$image');";

//Execute Query
$records = mysqli_query($connection,$sql);
echo '<script language="javascript">
alert("Data has been successfully uploaded");
window.location.replace("addition.php");
</script>';
}
?>





