<?php
 include('headerviewOrder.php');
 ?>
 
<section id="service">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="service-area">
            <div class="title-area">
              <h2 class="tittle">Order</h2>
              <span class="tittle-line"></span>	
              <p></p>
            </div>
			
			<!--Start of service content-->
			<div class="service-content">
				<table class="table table-bordered">
					<tr>
						<th width="5%">Order ID</th>
						<th width="10%">User ID</th>
						<th width="15%">Name</th>
						<th width="10%">Category</th>
						<th width="10%">Room</th>
						<th width="20%">Check In</th>
						<th width="20%">Check Out</th>
						<th width="10%">Status</th>
						<th width="10%">Action</th>


					</tr>
	<?php
	
if (isset($_POST['search']) && empty($_POST['search']) == false) {
			
			$orderIDEntered = $_POST['search'];
			
			//Connect mySQL
			$connection = mysqli_connect('localhost','root','','places');
			
			//Select Database
			mysqli_select_db($connection, 'view');
				
			//Select Query
			$sql = "SELECT * FROM view WHERE orderID = '" . $orderIDEntered . "';";
			
			//Execute Query
			$records = mysqli_query($connection,$sql);
		
		while($view = mysqli_fetch_array($records)){
			echo "<tr>";
			echo "<td style='text-align:center;'>".$view['orderID']."</td>";
			echo "<td style='text-align:center;'>".$view['userID']."</td>";
			echo "<td style='text-align:center;'>".$view['Name']."</td>";
			echo "<td style='text-align:center;'>".$view['Category']."</td>";
			echo "<td style='text-align:center;'>".$view['Room']."</td>";
			echo "<td style='text-align:center;'>".$view['Checkin']."</td>";
			echo "<td style='text-align:center;'>".$view['Checkout']."</td>";

			echo "<td style='text-align:center;'>".$view['Status']."</td>";
			echo "<td style='text-align:center;'>	
			<form action = 'updateStatus.php' method = 'POST'> 
				<input type = 'hidden' name='id' value  = '".$view['orderID']."'>
				<input type='submit' value='Complete'>
			</form>
			<br>
			";
			
			
			}
}
		else{
			
			//Connect mySQL
			$connection = mysqli_connect('localhost','root','','places');
			
			//Select Database
			mysqli_select_db($connection, 'view');
				
			//Select Query
			$sql = "SELECT * FROM view;";
			
			//Execute Query
			$records = mysqli_query($connection,$sql);
			
			while($view = mysqli_fetch_array($records)){
			echo "<tr>";
			echo "<td style='text-align:center;'>".$view['orderID']."</td>";
			echo "<td style='text-align:center;'>".$view['userID']."</td>";
			echo "<td style='text-align:center;'>".$view['Name']."</td>";
			echo "<td style='text-align:center;'>".$view['Category']."</td>";
			echo "<td style='text-align:center;'>".$view['Room']."</td>";
			echo "<td style='text-align:center;'>".$view['Checkin']."</td>";
			echo "<td style='text-align:center;'>".$view['Checkout']."</td>";

			echo "<td style='text-align:center;'>".$view['Status']."</td>";
			echo "<td style='text-align:center;'>	
			<form action = 'updateStatus.php' method = 'POST'> 
					<input type = 'hidden' name='id' value  = '".$view['orderID']."'>
					<input type='submit' value='Complete'>
					
			<br>";
			}
		}
	?>
</table>
<br>
</body>
</section>
<?php
include('footer.html');
?>
