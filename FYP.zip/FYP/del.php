<?php 
	//Connect mySQL
			$con = mysqli_connect('localhost','root','','places');
		
		//Select Database
			mysqli_select_db($con, 'destination');
		
		//Select Query
			$sql = "DELETE FROM destination WHERE ID = ".$_POST['id'].";";
		
		//Execute Query
			if(mysqli_query($con,$sql))
				header("refresh:1; url=delete.php");
			else
				echo "Not Deleted";
?>