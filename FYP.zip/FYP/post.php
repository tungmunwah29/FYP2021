<?php
session_start();
if(isset($_SESSION['name'])){
    $text = $_POST['text'];
	
	date_default_timezone_set("Asia/Singapore"); 

     
    $cb = fopen("log.html", 'a');
    fwrite($cb, "<div class='msgln'>(".date("d-m-Y H:i:s").") <b>".$_SESSION['name']."</b>: ".stripslashes(htmlspecialchars($text))."<br></div>");
    fclose($cb);
}
?>