 <?php
 include('headerAdmin.php');
 
		//Connect to MySQL
		$con = mysqli_connect('127.0.0.1','root','','places');
		
		//Select database
		mysqli_select_db($con,'destination');
		
		//Select query
		$sql = "SELECT * FROM destination WHERE ID = ".$_POST['id'];
		
		//Execute the query
		$records = mysqli_query($con, $sql);				
		$destination = mysqli_fetch_array($records);

		?>
 
<head>
</head>
<body>
  	<section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-md-5 col-sm-10 col-xs-12">
          <div class="contact-left wow fadeInLeft">
            <h2>Edit Hotel</h2>
			<form action="update.php" class="contact-form" method="post" enctype="multipart/form-data">
	        <div class="form-group">                

				  
	 
	<div class="form-group">                
    <input type="text" name = "name" class="form-control" placeholder="Name" value = "<?php echo $destination['Name']; ?>">
    </div>
	
  

	
	<div class="form-group" value = "<?php echo $destination['Category']; ?>">   
	Category:
	<select name = "category">
		<?php
			if ($destination['Category'] == "Penang") {
				echo "<option value='Penang' selected>Penang</option>";
			} else {
				echo "<option value='Penang'>Penang</option>";
			}
			
			if ($destination['Category'] == "Negeri Sembilan") {
				echo "<option value='Negeri Sembilan' selected='selected'>Negeri Sembilan</option>";
			} else {
				echo "<option value='Negeri Sembilan'>Negeri Sembilan</option>";
			}
			
			if ($destination['Category'] == "Perak") {
				echo "<option value='Perak' selected>Perak</option>";
			} else {
				echo "<option value='Perak'>Perak</option>";
			}
			if ($destination['Category'] == "Perak") {
				echo "<option value='Perak' selected>Perak</option>";
			} else {
				echo "<option value='Perak'>Perak</option>";
				
				
			}if ($destination['Category'] == "Johor") {
				echo "<option value='Johor' selected>Johor</option>";
			} else {
				echo "<option value='Johor'>Johor</option>";
			}
			
			if ($destination['Category'] == "Kedah") {
				echo "<option value='Kedah' selected>Kedah</option>";
			} else {
				echo "<option value='Kedah'>Kedah</option>";
			}
			
			if ($destination['Category'] == "Kelantan") {
				echo "<option value='Kelantan' selected>Kelantan</option>";
			} else {
				echo "<option value='Kelantan'>Kelantan</option>";
			}
			
			if ($destination['Category'] == "Malacca") {
				echo "<option value='Malacca' selected>Malacca</option>";
			} else {
				echo "<option value='Malacca'>Malacca</option>";
			}
			
			if ($destination['Category'] == "Pahang") {
				echo "<option value='Pahang' selected>Pahang</option>";
			} else {
				echo "<option value='Pahang'>Pahang</option>";
			}
			
			if ($destination['Category'] == "Perlis") {
				echo "<option value='Perlis' selected>Perlis</option>";
			} else {
				echo "<option value='Perlis'>Perlis</option>";
			}
			
			if ($destination['Category'] == "Sabah") {
				echo "<option value='Sabah' selected>Sabah</option>";
			} else {
				echo "<option value='Sabah'>Sabah</option>";
			}
			
			if ($destination['Category'] == "Sarawak") {
				echo "<option value='Sarawak' selected>Sarawak</option>";
			} else {
				echo "<option value='Sarawak'>Sarawak</option>";
			}
			
			if ($destination['Category'] == "Selangor") {
				echo "<option value='Selangor' selected>Selangor</option>";
			} else {
				echo "<option value='Selangor'>Selangor</option>";
			}
			
			if ($destination['Category'] == "Terrenganu") {
				echo "<option value='Terrenganu' selected>Terrenganu</option>";
			} else {
				echo "<option value='Terrenganu'>Terrenganu</option>";
			}
		?>
	</select>
    </div>
	
	<div class="form-group" value = "<?php echo $destination['Rooms']; ?>">   
	Type of Rooms:
	<select name = "rooms">
		<?php
			if ($destination['Rooms'] == "Single Bedroom") {
				echo "<option value='Single Bedroom' selected>Single Bedroom</option>";
			} else {
				echo "<option value='Single Bedroom'>Single Bedroom</option>";
			}
			
			if ($destination['Rooms'] == "Double Bedroom") {
				echo "<option value='Double Bedroom' selected='selected'>Double Bedroom</option>";
			} else {
				echo "<option value='Double Bedroom'>Double Bedroom</option>";
			}
			
			if ($destination['Category'] == "Large Bedroom") {
				echo "<option value='Large Bedroom' selected>Large Bedroom</option>";
			} else {
				echo "<option value='Large Bedroom'>Large Bedroom</option>";
			}
			
		?>
	</select>
    </div>
	
	
	
	<div class="form-group">                
    <input type="double" name = "price" class="form-control" placeholder="Price" value = "<?php echo $destination['Price']; ?>">
    </div> 
	

	<div class="form-group">                
    <input type="double" name = "profit" class="form-control" placeholder="Profit" value = "<?php echo $destination['Profit']; ?>">
    </div> 
	
	<div class="form-group" name = "rating" value = "<?php echo $destination['Rating']; ?>">   
	Ratings:	
	<select name = "rating">
	<option value="5">5</option>
	<option value="4">4</option>
	<option value="3">3</option>
	<option value="2">2</option>
	<option value="1">1</option>

	</select>
    </div>  
	
	<div class="form-group">                
    <input type="number" name="stockBalance" class="form-control" placeholder="Stock Balance"value = "<?php echo $destination['StockBalance']; ?>">
    </div>
	
	<div class="form-group">                
	<textarea name="description" class = "form-control" rows="5" cols="40" placeholder="Description"><?php echo $destination['Description']; ?></textarea>
    </div>

	<input type='hidden' name="ID"  value="<?php echo $destination['ID'];  ?>">
	
	
	<button type="submit" data-text="SUBMIT" class="button button-default"><span>Update</span></button>
	
	</form>
	</section>              
	<br>
	</form>
</body>
<?php
include('footer.html');
?>