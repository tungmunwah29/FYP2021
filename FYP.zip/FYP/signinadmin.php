<?php
	if(!isset($_SESSION))
		session_start();

	if(isset($_POST["submit"])){
		$id = $_POST["userID"];
		$pass = $_POST["password"];

		//check login credentials
		$conn = mysqli_connect('localhost', 'root', '', 'places');
		mysqli_select_db($conn, 'admin');
		
		$query = "SELECT * FROM admin WHERE UserID = '$id'";
		$result = mysqli_query($conn, $query);
		if(mysqli_num_rows($result) > 0){
			$query = "SELECT * FROM admin WHERE Password = '$pass'";
			$result = mysqli_query($conn, $query);
			if(mysqli_num_rows($result) > 0){
				$_SESSION['users'] = $id;
				$_SESSION['status'] = true;
				echo "<script>alert(\"You have successfully login into admin page\");</script>";
				echo "<script>location.href=\"admin.php\"</script>"; //redirect homepage
				exit();
			}
			else {
				$_SESSION['status'] = false;
				echo "<script>alert(\"You have fail to login admin page\");</script>";
				echo "<script>location.href=\"signinadmin.php?submitFail=true\"</script>";//reopen login modal
				exit();
			}
		

		
		// if($id=="admin" && $pass=="admin"){
			// $_SESSION['admin'] = $id;
			// echo "<script>alert(\"You have successfully login\");</script>";
			// echo "<script>location.href=\"index.php\"</script>"; //redirect homepage
			// exit();
		// }
		
	}
	}
	include 'header.php';

?>
	<!-- Start Log In section -->
	<section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="contact-left wow fadeInLeft">
            <h2>Sign In for Admins</h2>
            <form action="signinadmin.php" class="contact-form" method="post">
              <div class="form-group">                
                <input type="text" name="userID" class="form-control" placeholder="UserID">
              </div>              
              <div class="form-group">
               <input type="password" name="password" class="form-control" placeholder="Password">
              </div>
			  <input type='hidden' name="submitted" value='true'>
              <button type="submit" name="submit" data-text="SUBMIT" class="button button-default"><span>SIGN IN</span></button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Log In section -->

 <?php
	include('footer.html');
  
?>