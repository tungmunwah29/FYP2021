<?php
 include('headerAdmin.php');
 ?>
<section id="service">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="service-area">
            <div class="title-area">
              <h2 class="tittle">Account for Users</h2>
              <span class="tittle-line"></span>	
              <p></p>
            </div>
			
			<!--Start of service content-->
			<div class="service-content">
				<table class="table table-bordered">
					<tr>
						<th width="15%">User ID</th>
						<th width="20%">Name</th>
						<th width="15%">Password</th>
						<th width="15%">Email</th>
						<th width="10%">Birthday</th>
						<th width="40%">Address</th>

					</tr>
	<?php
		//Connect mySQL
			$connection = mysqli_connect('localhost','root','','places');
		
		//Select Database
			mysqli_select_db($connection, 'user');
			
		
		//Select Query
			$sql = "SELECT * FROM user";
		
		//Execute Query
			$records = mysqli_query($connection,$sql);
		
		while($user = mysqli_fetch_array($records)){
			echo "<tr>";
			echo "<td style='text-align:center;'>".$user['UserID']."</td>";
			echo "<td style='text-align:center;'>".$user['Name']."</td>";
			echo "<td style='text-align:center;'>".$user['Password']."</td>";
			echo "<td style='text-align:center;'>".$user['Email']."</td>";
			echo "<td style='text-align:center;'>".$user['Birthday']."</td>";
			echo "<td style='text-align:center;'>".$user['Address']."</td>";
			echo" 
			</table>";
			echo "</tr>";
			
			
		}
	?>
</table>
<br>
</body>
</section>
<?php
include('footer.html');
?>

