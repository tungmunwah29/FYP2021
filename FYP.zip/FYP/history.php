<?php
	session_start();
if(isset($_SESSION['status'])){
	if($_SESSION['status'] == true)	
		include('headerCustomer.php');
}
else{
	echo "<script>alert('Please sign in');</script>";
	echo "<script>location.href='signin.php'</script>";
	exit();
}
 ?>
 
<section id="service">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="service-area">
					<div class="title-area">
						<h3 class="tittle">Check Order</h3>
						<span class="tittle-line"></span>	
						<p></p>
					</div>
					<style>
						table, th, td {
						border: 1px solid black;
						border-collapse: collapse;
						}


					</style>
					<div class="service-content">
								<table class="table table-bordered">
									<tr>
										<th>Order ID</th>
										<th>Name</th>
										<th>Category</th>
										<th>Type of Rooms</th>
										<th>Check in</th>
										<th>Check out</th>
										<th>Status</th>
										<th>Cancel Booking</th>

									</tr>
									<?php
										
										$conn = mysqli_connect('localhost', 'root','','places');
										mysqli_select_db($conn, 'view');
										if(isset($_SESSION['users'])){
										$userID = $_SESSION['users'];
										
										$id = "SELECT * from user WHERE UserID='$userID'";
										$run_id=mysqli_query($conn, $id);
																				
										$user = mysqli_fetch_array($run_id);
										$userName = $user['UserID'];
										$query = "SELECT * from view WHERE userID='$userName'";
										$result = mysqli_query($conn, $query);

										
											while ($row = $result->fetch_assoc()){
												echo "<tr><th>" . $row["orderID"]. "</th> 
												<th>" . $row["Name"]. "</th> 
												<th>" . $row["Category"]. "</th> 
												<th>" . $row["Room"]. "</th>
												<th>" . $row["Checkin"]. "</th>
												<th>" . $row["Checkout"]. "</th>
												<th>" . $row["Status"]. "</th>
												
												
												<td>
												<form action = 'delHis.php' method = 'POST'> 
												<input type = 'hidden' name='orderID' value  = '".$row['orderID']."'>
												<input type='submit' value='Cancel Booking'>
												</form>
												
												
												</td> 
												</tr>";
											}
									}

									?>
								</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
		
<?php
	include('footer.html');
 ?>