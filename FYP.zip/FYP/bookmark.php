<?php
	session_start();
if(isset($_SESSION['status'])){
	if($_SESSION['status'] == true)	
		include('headerCustomer.php');
	else
	include('header.php');
}
else{
	echo "<script>alert('Please sign in');</script>";
	echo "<script>location.href='signin.php'</script>";
	exit();
}

?>

<?php
	
	//Connect mySQL
	$connection = mysqli_connect('127.0.0.1','root','','places');
			
	//Select Database
	mysqli_select_db($connection, 'booking');
	
	function getIP(){
		$ip = $_SERVER['REMOTE_ADDR'];
				
		if(!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		}
		else if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		};
				
		return $ip;
	}
	
	
	if (isset($_POST['pro_ID'])){
				$ip = getIP();
				$pro_ID = $_POST['pro_ID'];

		
				$check = "SELECT * FROM booking WHERE ID ='$pro_ID' AND ip_address='$ip'";
				$run_check = mysqli_query($connection, $check);
				
				$product =mysqli_fetch_array($run_check);
				
				if(mysqli_num_rows($run_check)==0){
					$insert = "INSERT into booking (ID,ip_address) values ('$pro_ID','$ip')";
					$run_insert = mysqli_query($connection, $insert);
					
					$sql = "SELECT * FROM destination WHERE ID = '$pro_ID'";
					$run_sql = mysqli_query($connection, $sql);
					$products = mysqli_fetch_array($run_sql);

						
					echo"<script>window.open('bookmark.php','_self')</script>";
				}else{

						
						$insert = "INSERT into booking (ID,ip_address) values ('$pro_ID','$ip')";
						$run_insert = mysqli_query($connection, $insert);
						echo"<script>window.open('bookmark.php','_self')</script>";
						
					}
				}
					
		
	
	
	if(isset($_GET['action'])){
		
		if(isset($_GET['id'])){
			if($_GET['action'] == 'delete')
			{
				$ip = getIP();
				$productID = $_GET['id'];
		
				$delete_product = "DELETE from booking where ID =$productID AND ip_address='$ip'";
				$run_delete_product = mysqli_query($connection, $delete_product);
				
				
					$sql = "SELECT * FROM destination WHERE ID = '$pro_ID'";
					$run_sql = mysqli_query($connection, $sql);
					$products = mysqli_fetch_array($run_sql);
			
				if($run_delete_product){
					echo"<script>window.open('bookmark.php','_self')</script>";
				}
				
			
		}
	}
	}
?>
	
<section id="service">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="service-area">
            <div class="title-area">
              <h2 class="tittle">Bookmark</h2>
              <span class="tittle-line"></span>	
              <p></p>
            </div>
			
			<!--Start of service content-->
			<div class="service-content">
				<table class="table table-bordered">
					<tr>
						<th width="40%">Item Name</th>						
						<th width="40%">Image</th>
						<th width="10%">Category</th>
						<th width="10%">Types of Rooms</th>
						<th width="20%">Price</th>
						<th width="5%">View</th>
						<th width="5%">Remove</th>

					</tr>
					
					<?php 
						
						global $connection;
						
						$ip = getIP();
						$sel_price = "SELECT * FROM booking WHERE ip_address = '$ip'";
						$run_price = mysqli_query($connection, $sel_price);
						
						while($p_price=mysqli_fetch_array($run_price)){
							
							$pro_id = $p_price['ID'];

							
							$pro_price = "SELECT * from destination WHERE ID = '$pro_id'";
							$run_pro_price = mysqli_query($connection, $pro_price);
							
							while($pp_price=mysqli_fetch_array($run_pro_price)){
								
								$product_category = $pp_price['Category'];
								$product_image = $pp_price['Image'];
								$product_room = $pp_price['Rooms'];
								$product_name = $pp_price['Name'];
								$product_image = $pp_price['Image'];
								$single_price =$pp_price['Price'];
					?>
					<tr>
						<td width="20%"><?php echo $product_name ?></td>
						<td width="40%"><img src="<?php echo $product_image ?>"height='200' width='200'></td>
						<td width="20%"><?php echo $product_category ?></td>
						<td width="20%"><?php echo $product_room ?></td>
						<td width="20%"><?php echo "RM" . $single_price ?></td>
						
						<td><a href="details.php?action=1&id=<?php echo $pro_id ?>" class="btn btn-dark btn-primary btn-sm btn-book">View</a></td>
						<td><a href="bookmark.php?action=delete&id= <?php echo $pro_id  ?>" class="btn btn-dark btn-primary btn-sm btn-book">Delete</a></td> 


						
					</tr>
					<?php 	} 
						} 
					?>
					

				</table>
				
				
			</div>
		</div>	
	</div>
</section>
<?php
include('footer.html');
?>