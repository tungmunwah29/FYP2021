
<?php

session_start();
if(isset($_SESSION['status'])){
	if($_SESSION['status'] == true)	
		include('headerCustomer.php');
	else
	include('header.php');
}
else
	include('header.php');
 ?>
 
 
 
  <!-- Start header section -->  
  <header id="header">
    <div class="header-inner">
      <!-- Header image -->
      <img src="assets/images/header-bg.jpg" alt="img">
      <div class="header-overlay">
        <div class="header-content">
        <!-- Start header content slider -->
        <h2 class="header-slide">We Have
          <span>The Best </span>
          <span>Enjoyable</span>
          <span>Good Deals For</span>
          Tourists</h2>
        <!-- End header content slider -->  
        <!-- Header btn area -->
        <div class="header-btn-area">
          <a class="knowmore-btn" href="about.php">KNOW MORE</a>
        </div>
      </div>
      </div>      
    </div>
</body>
  <!-- End header section -->

  <!-- End Testimonial section -->
   <?php
include('footer.html');
?>