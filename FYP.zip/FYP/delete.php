<?php
 include('headerEdit&Delete.php');
 ?>
 
<section id="service">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="service-area">
            <div class="title-area">
              <h2 class="tittle">Edit And Delete</h2>
              <span class="tittle-line"></span>	
              <p></p>
            </div>
			
			<!--Start of service content-->
			<div class="service-content">
				<table class="table table-bordered">
					<tr>
						<th width="5%">ID</th>
						<th width="10%">Name</th>
						<th width="10%">Category</th>
						<th width="8%">Type of Rooms</th>
						<th width="8%">Price</th>
						<th width="8%">Profit</th>
						<th width="8%">Rating</th>
						<th width="8%">Stock Balance</th>
						<th width="25%">Description</th>
						<th width="25%">Image</th>
						<th width="25%">Action</th>

					</tr>
				
	
	<?php
	

		
		
		if (isset($_POST['search']) && empty($_POST['search']) == false) {
			
			$destinationNameEntered = $_POST['search'];
			
			//Connect mySQL
			$connection = mysqli_connect('localhost','root','','places');
			
			//Select Database
			mysqli_select_db($connection, 'destination');
				
			//Select Query
			$sql = "SELECT * FROM destination WHERE Name = '" . $destinationNameEntered . "';";
			
			//Execute Query
			$records = mysqli_query($connection,$sql);
			


			
			while($destination = mysqli_fetch_array($records)){
				
				
				echo "<tr>";
				echo "<td style='text-align:center;'>".$destination['ID']."</td>";
				echo "<td style='text-align:center;'>".$destination['Name']."</td>";
				echo "<td style='text-align:center;'>".$destination['Category']."</td>";
				echo "<td style='text-align:center;'>".$destination['Rooms']."</td>";
				echo "<td style='text-align:center;'>".$destination['Price']."</td>";
				echo "<td style='text-align:center;'>".$destination['Profit']."</td>";
				echo "<td style='text-align:center;'>".$destination['Rating']."</td>";
				echo "<td style='text-align:center;'>".$destination['StockBalance']."</td>";
				echo "<td style='text-align:center;'>".$destination['Description']."</td>";
				echo "<td style='text-align:center;'><img src = '".$destination['Image'] . "' height='200' width='200'></td>" ;
				echo" <td><table border=0'><td style='border-left: none;'>
				<form action = 'del.php' method = 'POST'> 
					<input type = 'hidden' name='id' value  = '".$destination['ID']."'>
					<input type='submit' value='Delete'>
				</form>
				<br>
				<form action = 'edit.php' method = 'POST'> 
					<input type = 'hidden' name='id' value  = '".$destination['ID']."'>
					<input type='submit' value='Edit'>
				</form>
				</td></table></td>";
				echo "</tr>";
				
			}
			
		} else {
			
			//Connect mySQL
				$connection = mysqli_connect('localhost','root','','places');
			
			//Select Database
				mysqli_select_db($connection, 'destination');
				
			
			//Select Query
				$sql = "SELECT * FROM destination";
			
			//Execute Query
				$records = mysqli_query($connection,$sql);
			
			while($destination = mysqli_fetch_array($records)){
				
				if ($destination['StockBalance'] < 3){
				echo "<script type='text/javascript'>
				alert('Destination ID " . $destination['ID'] . " is less than 3 products. Please restock ASAP.');
				</script>";
				}
				
				echo "<tr>";
				echo "<td style='text-align:center;'>".$destination['ID']."</td>";
				echo "<td style='text-align:center;'>".$destination['Name']."</td>";
				echo "<td style='text-align:center;'>".$destination['Category']."</td>";
				echo "<td style='text-align:center;'>".$destination['Rooms']."</td>";
				echo "<td style='text-align:center;'>".$destination['Price']."</td>";
				echo "<td style='text-align:center;'>".$destination['Profit']."</td>";
				echo "<td style='text-align:center;'>".$destination['Rating']."</td>";
				echo "<td style='text-align:center;'>".$destination['StockBalance']."</td>";
				echo "<td style='text-align:center;'>".$destination['Description']."</td>";
				echo "<td style='text-align:center;'><img src = '".$destination['Image'] . "' height='200' width='200'></td>" ;
				echo" <td><table border=0'><td style='border-left: none;'>
				<form action = 'del.php' method = 'POST'> 
					<input type = 'hidden' name='id' value  = '".$destination['ID']."'>
					<input type='submit' value='Delete'>
				</form>
				<br>
				<form action = 'edit.php' method = 'POST'> 
					<input type = 'hidden' name='id' value  = '".$destination['ID']."'>
					<input type='submit' value='Edit'>
				</form>
				</td></table></td>";
				echo "</tr>";
				
				
			}
		}
				
	?>
</table>
<br>
</body>
</section>
<?php
include('footer.html');
?>
