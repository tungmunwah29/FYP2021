<?php
 session_start();
if(isset($_SESSION['status'])){
	if($_SESSION['status'] == true)	
		include('headerCustomer.php');
	else
	include('header.php');
}
else
	include('header.php');
 


	
?>
 
<!-- Start service section -->
 <section id="service">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="service-area">
            <div class="title-area">
              <h2 class="tittle">Categories</h2>
              <span class="tittle-line"></span>	
              <p></p>
            </div>
			
            <!-- service content -->
            <div class="service-content">
              <ul class="service-table">
				<li class="col-md-4 col-sm-4">
                  <div class="single-service wow slideInUp">
					<a href="product.php?category=Penang"><img src="images/12.jpg" width="250" height="250" alt="" ></a>
					<h4 class="service-title">Penang</h4>
				  </div>
				</li>
				<li class="col-md-4 col-sm-4">
				  <div class="single-service wow slideInUp">
					<a href="product.php?category=Negeri Sembilan"><img src="images/Sembilan.jpg" width="250" height="250" alt=""></a>
					<h4 class="service-title">Negeri Sembilan</h4>
				  </div>
				</li>
				<li class="col-md-4 col-sm-4">
				  <div class="single-service wow slideInUp">
					<a href="product.php?category=Perak"><img src="images/Perak.jpg" width="250" height="250" alt=""></a>
					<h4 class="service-title">Perak</h4>
				  </div>
				</li>
				
				<li class="col-md-4 col-sm-4">
				  <div class="single-service wow slideInUp">
					<a href="product.php?category=Johor"><img src="images/Johor.jpg" width="250" height="250" alt=""></a>
					<h4 class="service-title">Johor</h4>
				  </div>
				</li>
				
				<li class="col-md-4 col-sm-4">
				  <div class="single-service wow slideInUp">
					<a href="product.php?category=Kedah"><img src="images/Kedah.jpg" width="250" height="250" alt=""></a>
					<h4 class="service-title">Kedah</h4>
				  </div>
				</li>
				
				<li class="col-md-4 col-sm-4">
				  <div class="single-service wow slideInUp">
					<a href="product.php?category=Kelantan"><img src="images/Kelantan.jpg" width="250" height="250" alt=""></a>
					<h4 class="service-title">Kelantan</h4>
				  </div>
				</li>
				
				<li class="col-md-4 col-sm-4">
				  <div class="single-service wow slideInUp">
					<a href="product.php?category=Malacca"><img src="images/Malacca.jpg" width="250" height="250" alt=""></a>
					<h4 class="service-title">Malacca</h4>
				  </div>
				</li>
				
				<li class="col-md-4 col-sm-4">
				  <div class="single-service wow slideInUp">
					<a href="product.php?category=Pahang"><img src="images/Pahang.jpg" width="250" height="250" alt=""></a>
					<h4 class="service-title">Pahang</h4>
				  </div>
				</li>
				
				<li class="col-md-4 col-sm-4">
				  <div class="single-service wow slideInUp">
					<a href="product.php?category=Perlis"><img src="images/Perlis.jpg" width="250" height="250" alt=""></a>
					<h4 class="service-title">Perlis</h4>
				  </div>
				</li>
				
				<li class="col-md-4 col-sm-4">
				  <div class="single-service wow slideInUp">
					<a href="product.php?category=Sabah"><img src="images/Sabah.jpg" width="250" height="250" alt=""></a>
					<h4 class="service-title">Sabah</h4>
				  </div>
				</li>
				
				<li class="col-md-4 col-sm-4">
				  <div class="single-service wow slideInUp">
					<a href="product.php?category=Sarawak"><img src="images/Sarawak.jpg" width="250" height="250" alt=""></a>
					<h4 class="service-title">Sarawak</h4>
				  </div>
				</li>
				
				<li class="col-md-4 col-sm-4">
				  <div class="single-service wow slideInUp">
					<a href="product.php?category=Selangor"><img src="images/Selangor.jpg" width="250" height="250" alt=""></a>
					<h4 class="service-title">Selangor</h4>
				  </div>
				</li>
				
				
				<li class="col-md-4 col-sm-4">
				  <div class="single-service wow slideInUp">
					<a href="product.php?category=Terengganu"><img src="images/terrengganu.jpg" width="250" height="250" alt=""></a>
					<h4 class="service-title">Terengganu</h4>
				  </div>
				</li>
			
			  </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End service section -->
<?php



include('footer.html');
?>