<?php
	session_start();
if(isset($_SESSION['status'])){
	if($_SESSION['status'] == true)	
		include('headerCustomer.php');
}
else{
	echo "<script>alert('Please sign in');</script>";
	echo "<script>location.href='signin.php'</script>";
	exit();
}
 ?>

<!DOCTYPE html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <script
    src="https://www.paypal.com/sdk/js?client-id=Adu4sTz2Ug21Aj5ZxvsynJYJlz_OBmAxK4NPxxedVtqL1GsnRlmqhQSbpw1ooyyE5heZ6bNHw6qilXZT&currency=MYR">
  </script>
</head>

<body>
		<section id="service">
			<div class="row">
				<div class="col-md-12">
					<div class="service-area">
						<div class="title-area">
							<h2 class="tittle">Payment</h2>
							<span class="tittle-line"></span>	
							<p></p>
						</div>
					</div>
				</div>
			</div>
			<div id="paypal-button-container" class="service-content" align="middle"></div>
		</section>
  <?php
	
	//Connect to database
	$connection = mysqli_connect('127.0.0.1','root','','places');
	//Select database
	mysqli_select_db($connection, 'places');
	
	if(isset($_POST['productName'])){
		if(isset($_POST['userName'])){
			if(isset($_POST['productRoom'])){
					if(isset($_POST['productCategory'])){
						if(isset($_POST['productPrice'])){
							if(isset($_POST['productCheckin'])){
								if(isset($_POST['productCheckout'])){
									if(isset($_POST['productProfit'])){

							$p_name = $_POST['productName'];
							$u_name = $_POST['userName'];
							$p_room = $_POST['productRoom'];
							$p_Category = $_POST['productCategory'];
							$p_price = $_POST['productPrice'];		
							$p_checkin = $_POST['productCheckin'];		
							$p_checkout = $_POST['productCheckout'];	
							$p_profit = $_POST['productProfit'];

						
							
							$insert = "INSERT into view (userID, Name, Category, Room ,Price,Checkin,Checkout,Profit) 
							values ('$u_name','$p_name', '$p_Category', '$p_room','$p_price','$p_checkin','$p_checkout','$p_profit')";
							$run_insert = mysqli_query($connection, $insert);
							}
						}
					}
				}
			}
		}
	}
	}
	
	
	if(isset($_POST['total'])){
		$total = $_POST['total'];
		
		echo"
		<script>
  paypal.Buttons({
    createOrder: function(data, actions) {
      return actions.order.create({
        purchase_units: [{
          amount: {
            value: $total
          }
        }]
      });
    },
    onApprove: function(data, actions) {
      // Capture the funds from the transaction
      return actions.order.capture().then(function(details) {
        // Show a success message to your buyer
        alert('Transaction completed by ' + details.payer.name.given_name);
      });
    }
  }).render('#paypal-button-container');
</script>
		";
	}
  ?>
</body>

<?php
	include('footer.html');
 ?>