<?php
 include('headerAdmin.php');
 ?>
 
 
 
  	<section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-sm-10 col-xs-12">
          <div class="contact-left wow fadeInLeft">
            <h2>Add Destination</h2>
			<form action="insert.php" class="contact-form" method="post" enctype="multipart/form-data">
	        <div class="form-group">                

	  
	 

	<div class="form-group">                
    <input type="text" name = "name" class="form-control" placeholder="Name">
    </div>
	
	
    <div class="form-group">   
	<p>Category:</p>	
	<select name = "category">
	<option value="Penang">Penang</option>
	<option value="Negeri Sembilan">Negeri Sembilan</option>
	<option value="Perak">Perak</option>
	<option value="Johor">Johor</option>
	<option value="Kedah">Kedah</option>
	<option value="Kelantan">Kelantan</option>
	<option value="Malacca">Malacca</option>
	<option value="Pahang">Pahang</option>
	<option value="Perlis">Perlis</option>
	<option value="Sabah">Sabah</option>
	<option value="Sarawak">Sarawak</option>
	<option value="Selangor">Selangor</option>
	<option value="Terrenganu">Terrenganu</option>
	</select>
    </div>  
	
	<div class="form-group">   
	<p>Types of Rooms:</p>	
	<select name = "rooms">
	<option value="Single Bedroom">Single Bedroom</option>
	<option value="Double Bedroom">Double Bedroom</option>
	<option value="Large Bedroom">Large Bedroom</option>
	</select>
    </div>  
	
	<div class="form-group">                
    <input type="double" name = "price" class="form-control" placeholder="Price">
    </div> 
	

	
	<div class="form-group">                
    <input type="double" name = "profit" class="form-control" placeholder="Profit">
    </div> 
	
	
	<div class="form-group">   
	Ratings:	
	<select name = "rating">
	<option value="5">5</option>
	<option value="4">4</option>
	<option value="3">3</option>
	<option value="2">2</option>
	<option value="1">1</option>

	</select>
    </div>  
	
	<div class="form-group">                
    <input type="number" name="stockBalance" class="form-control" placeholder="Stock Balance">
    </div>
	   
	
	<div class="form-group">                
	<textarea name="description" class = "form-control" rows="5" cols="40" placeholder="Description"></textarea>
    </div>
	
	<div class="form-group">                
    <input type="text" name = "location" class="form-control" placeholder="Location">
    </div>
	

	Choose Image:
	<br><input type="file" name="fileToUpload" id="fileToUpload" ></br>

	
	<button type="submit" data-text="SUBMIT" class="button button-default"><span>Add</span></button>
	
	</form>
	</section>

</body>
<?php
include('footer.html');
?>
