<?php
 session_start();
if(isset($_SESSION['status'])){
	if($_SESSION['status'] == true)	
		include('headerCustomer.php');
	else
	include('header.php');
}
else
	include('header.php');
 
			//Connect mySQL
			$connection = mysqli_connect('127.0.0.1','root','','places');
			
			//Select Database
			mysqli_select_db($connection, 'destination');

			//cart function
			function getIP(){
				$ip = $_SERVER['REMOTE_ADDR'];
				
				if(!empty($_SERVER['HTTP_CLIENT_IP'])) {
					$ip = $_SERVER['HTTP_CLIENT_IP'];
				}
				else if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
					$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
				};
				
				return $ip;
			}
			
	
?>
<?php 
getIP();
							
?>

<?php

   global $connection;
	if(isset($_GET['id'])){
	$id = $_GET['id'];
	

		//Select Query
		$sql = "SELECT * FROM destination where ID='$id'";
			
		//Execute Query
		$records = mysqli_query($connection,$sql);
							
			while($row = mysqli_fetch_array($records)){
			//$quantity =$row['Quantity'];
			$ID = $row['ID'];
			$name = $row['Name'];
			$room = $row['Rooms'];
			$location = $row['Location'];
			

			$price = $row['Price'];

			$category = $row['Category'];
			$description = $row['Description'];
			$image = $row['Image'];
			$rating = $row['Rating'];
							
				
			echo"
			<section id='service'>
			<div class='row'>

			<div class='about-area'>

			<div class='col-md-12'>
			<div class='service-area'>
			<div class='title-area'>
			<h2 class='tittle'>$name</h2>
				<span class='tittle-line'></span>	
			<p></p>
			</div>
													
			<div class='row'>
			<div class='col-md-12'>
			<div class='about-area'>
			<div class='row'>
			<div class='col-md-5 col-sm-6 col-xs-12'>
			<img src=$image height='400' width='400'>
			</div>
			<p style = 'font-size : 20px;' name=room>Type of Rooms : $room</p>
			<p style = 'font-size : 20px;' name=rates>Ratings : $rating</p>											
		
			<p style = 'font-size : 20px;' name=product_price>Price : RM$price.00</p>
			<p style = 'font-size : 20px;' name=amenities>Amenities : Wifi, Gym , Parking Lot, TV and Breakfast Buffet which will be available everyday on 8am to 11am.</p>
			<p style = 'font-size : 20px;'> <b><u>Description</u></b> <br>$description</br></p>
			<p></p>
			<a href='$location' class='btn btn-dark btn-primary btn-sm btn-book'>Location</a>
			<p></p>
			<form action = 'bookmark.php' method = 'POST'>
            <input type='hidden' name='pro_ID' value='$id'>
			<button type='submit' data-text='Add to Bookmark' class='btn btn-dark btn-primary btn-sm btn-book'><span>Add to Bookmark</span></button>
			</form>
			</div>
			</button>
			</form>
			
			

			<div class='col-md-7 col-sm-6 col-xs-12'>
			<div class='about-right wow fadeInRight'>
			<div class='title-area'>
			</form>
			</div>
			</li>	
			</ul>
			</div>
			</div>
			</div>
			</div>
			</div>
			</section> ";
			
	
			
								
			echo" 
				<div class='col-sm-3 col-md-3'>
								
				<div class='single-service wow slideInUp'>
				<form action = 'newCart.php' method = 'POST'>
										
				<img src = 'images/testing.png' height='300' width='300'>
				<h4 class='service-title'>$room</h4>
				<p>Price : RM$price per room</p>
				 <div class='form-group mb-3'>
                    <label for=''>Checking in</label>
                        <input type='date' name='checkin' class='form-control' />
                </div>
				<div class='form-group mb-3'>
                    <label for=''>Checking out</label>
                    <input type='date' name='checkout' class='form-control' />
                </div>
				<p style = 'font-size : 20px'>Quantity: 
					<select id = 'qty' name = 'Quantity'>
					<option>1</option>
					<option>2</option>
					<option>3</option>
					<option>4</option>
					<option>5</option>
				</select></p>
				<input type='hidden' name='pro_ID' value='$id'>
				<button type='submit' data-text='Add to Cart' class='button button-default'><span>Add to Cart</span></button>
				</div>
				</button>

				</form>
				</div>
				</div>";
		}
							
	}		
?>	



<section id='service'>
			<div class='title-area'>
			<h2 class='tittle'>Users Reviews and Ratings</h2>
				<span class='tittle-line'></span>	
			<p></p>
</div>


<?php

	//Select Query
	
     // $con = mysqli_connect("localhost","root","","test");
     // include('connection.php');
     $dbhost = 'localhost';
     $dbuser = 'root';
     $dbpass = '';
     $dbname = 'places';
     $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);


     if(! $conn ) {
          die('Could not connect: ' . mysqli_error());
     }
	 
	$sql = "SELECT * FROM rating where Destination_ID='$id'";
    $result = mysqli_query($conn, $sql);
	

     if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
		    $Name = $row['Names'];
            $rate = $row['Rate'];
			$message = $row['Message'];
            $time = $row['Timeline'];

?>

			<section id='service'>
			<div class='row'>
                    

			<div class='col-md-8 col-xs-12'>

	               <div class='container' id='userReview'>	
	               <h4> 
		          <!-- user who added the review. take username  -->
		          <h4 class='fa fa-user'> Name:</h4> <?= $Name; ?> &nbsp;&nbsp;&nbsp;
		          <h4 class='fa fa-calendar'></h4> 
		
				<?= $time; ?>
		          
		          <!-- 12/06/2020 10:30  -->
		          &nbsp;&nbsp;&nbsp;
				<br>
				<?= $rate; ?>
					<?php
					for( $x = 0; $x < 5; $x++ )
					{
					if( floor( $rate )-$x >= 1 ) //rating in int 
					{ echo '<i class="fa fa-star"></i>'; } //white star picture
					else
					{ echo '<i class="fa fa-star-o"></i>'; } //black star picture
					}
					?>
				

		         <p>
				<?= $message; ?>
		         	</p>
                    </h4>
	
	          </div>
	 </div>
						 
                         
			
		
			</div>
			</div>
			</section> 
			<?php
		  }
	}
	
	 
	 
	 ?>
	 
<?php

	//Select Query
	$sql = "SELECT * FROM destination where ID='$id'";
			
	//Execute Query
	$records = mysqli_query($connection,$sql);
							
	while($row = mysqli_fetch_array($records)){
	$ID = $row['ID'];
		
		

?> 
	 
	 
<section id='service'>

			<div class='about-area'>
			<div class='col-md-12'>
			<div class='service-area'>
		
                    <div class='col-md-8 col-xs-12'>

						 
						 
                         <h4>Leave a Review</h4>

                        <form action="rating.php" method="post" class="form">

                              <div class="row">
                                   <div class="col-sm-6 col-xs-6">
                                        <div class="form-group">
                                             <label class="control-label">Name</label>
                                             <input type="text" name="name" class="form-control">
                                        </div>
										<div class="form-group">
                                             <label class="control-label">Hotel ID</label>
											<input type="number_format" name="hotel_ID" placeholder="Please do not change the ID" value = <?php echo $row['ID'] ?> >
                                        </div>
                                   </div>
								   
								<div class="col-sm-6 col-xs-6">
                                    <div class="form-group">
                                        <label class="control-label">Rate this hotel</label>

										<input type="range" for="Rating" value="5" min="0" max="5" 
										oninput="this.nextElementSibling.value = this.value" name="rating"><output>5 </output><br>
									</div>
                                </div>
                              </div>
								   
								   
							


                              <div class="form-group">
                                   <label class="control-label">Message</label>
									<textarea class="form-control" rows="6" name="message" required></textarea>
                              </div>

                              <button type="submit" class="section-btn btn btn-primary">Submit</button>
                         </form>
                    </div>
			
		
			</div>
			</div>
			</div>
			</section>	 
	 
 

<?php
	}
	
include('footer.html');
?>