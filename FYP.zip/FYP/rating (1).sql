-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2021 at 07:08 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `places`
--

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `ReviewID` int(10) NOT NULL,
  `Destination_ID` int(100) NOT NULL,
  `Names` varchar(50) NOT NULL,
  `Rate` int(10) NOT NULL,
  `Message` longtext NOT NULL,
  `Timeline` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`ReviewID`, `Destination_ID`, `Names`, `Rate`, `Message`, `Timeline`) VALUES
(4, 1, 'test1', 2, 'test1', '2021-10-13 15:33:37'),
(5, 2, 'test', 5, 'test', '2021-10-25 15:33:40'),
(6, 5, 'testing 5', 5, '5555', '2021-10-27 15:36:08'),
(7, 5, 'eeeeeeeeee', 5, 'eeeeeeee', '2021-10-27 15:56:43'),
(8, 3, 'testing3', 5, 'Pls tell me this is testing 3', '2021-10-27 15:58:41'),
(9, 4, 'Testing 4', 5, 'I think this place is good enough for everyone stay', '2021-10-27 16:33:21'),
(10, 4, 'Tung Mun Wah', 1, 'Its a bad place', '2021-10-27 16:34:29'),
(11, 1, 'testing 12345', 5, 'sssssssssss', '2021-10-27 16:48:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`ReviewID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `ReviewID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
