<?php 
    session_start();

    if(isset($_SESSION['status'])){
        if($_SESSION['status'] == true)	
            include('headerCustomer.php');
        else
            include('header.php');
            
    }
    else 
        include('header.php');

?>
<?php 

     $connection = new mysqli('localhost', 'root', '', 'places');
	 
	 //Select Database
	mysqli_select_db($connection, 'destination');
	 
?>


<!-- Start service section -->
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-3">
            <form action="product.php" method="GET">
                <input name="category" type="text" value="<?=$_GET['category']   ?>" hidden/>
                <div class="card shadow mt-3" style="margin-top:30px!important;">
                    <div class="card-header">
                        <h5>Filter
                        <button type="submit" class="btn btn-primary btn-sm float-end">Search</button>
                        </h5>
                    </div>
                <div class="card-body">
                <h5>Rating</h5>
                <hr>
				</div>
				</div>

		


<?php
        // load rating
        $sql = "SELECT DISTINCT Rating FROM destination ORDER BY Rating;";
        $result = $connection->query($sql);
        // continue if database returns rows
        if ($result->num_rows > 0) {
            // iterate each row
            while($row = $result->fetch_assoc()) {
                $checked = [];

                if(isset($_GET['rating']))
                    $checked = $_GET['rating'];
?>
                <div>
                    <input type="checkbox" name="rating[]" value="<?php echo $row['Rating'] ?>"
                        <?php if(in_array($row['Rating'], $checked)){ echo "checked"; } ?> 
                    />

                    <?= number_format((double)$row['Rating'],1,'.',''); ?> Star/s 
                </div>
<?php
            }
        }
        // database does not return any row
        else {
            echo "<script>alert('Error while retrieving rating from database!');</script>";
        }
    
?>
                <h5>Price</h5>
                <hr>
<?php
        // load prices
        $sql = "SELECT DISTINCT Price FROM destination ORDER BY Price;";
        $result = $connection->query($sql);
        // continue if database returns rows
        if ($result->num_rows > 0) {
            // iterate each row
            while($row = $result->fetch_assoc()) {
                $checked = [];

                if(isset($_GET['price']))
                    $checked = $_GET['price'];

?>
                <div>
                    <input type="checkbox" name="price[]" value="<?php echo $row['Price'] ?>"
                        <?php if(in_array($row['Price'], $checked)){ echo "checked"; } ?>
                    />
                    RM<?= $row['Price']; ?>.00
                </div>
<?php
            }
        }
        // database does not return any row
        else {
            echo "<script>alert('Error while retrieving rating from database!');</script>";
        }
?>
                <h5>Type of Rooms</h5>
                <hr>
<?php
    // load rooms
    $sql = "SELECT DISTINCT Rooms FROM destination ORDER BY Rooms;";
    $result = $connection->query($sql);
    // continue if database returns rows
    if ($result->num_rows > 0) {
        // iterate each row
        while($row = $result->fetch_assoc()) {
            $checked = [];

            if(isset($_GET['rooms']))
                $checked = $_GET['rooms'];

?>
                <div>
                    <input type="checkbox" name="rooms[]" value="<?php echo $row['Rooms'] ?>"
                        <?php if(in_array($row['Rooms'], $checked)){ echo "checked"; } ?>
                    />
                    <?= $row['Rooms']; ?>
                </div>
<?php
        }
    }
    // database does not return any row
    else {
        echo "<script>alert('Error while retrieving rating from database!');</script>";
    }

?>
            </form>
        </div>
<?php 
    if (isset($_GET['category']) && $_GET['category'] != '') {
        // get the value of category
        $category = $_GET['category'];
?>
        <div class="col-lg-9">
            <h3 id="textChange"><?= $category ?></h3>
			<h4>List of Destination </h4>
            <hr>
        <div class="row" id="result">
<?php 
        // This sql for retrieving destination that matches the filter options. 
        $sql = "SELECT * FROM destination WHERE Category='$category'";

        $ratingStr = '';
        $priceStr = '';
        $roomsStr ='';
        
        
        // for filtering Ratings
        if (isset($_GET['rating'])) {
            // generate the where statement for Ratings
            $ratingStr = 'Rating IN(';
            for ($i = 0; $i < sizeof($_GET['rating']); $i++)
                $ratingStr .= $_GET['rating'][$i] . ',';

            // remove comma
            $size = strlen($ratingStr);
            if (substr($ratingStr, $size-1, 1) == ',')
                $ratingStr = substr($ratingStr, 0, $size-1);
            $ratingStr .= ')';
        }

        // for filtering prices
        if (isset($_GET['price'])) {
            // generate the where statement for pickups
            $priceStr = 'Price IN(';
            for ($i = 0; $i < sizeof($_GET['price']); $i++)
                $priceStr .= $_GET['price'][$i] . ',';

            // remove comma
            $size = strlen($priceStr);
            if (substr($priceStr, $size-1, 1) == ',')
                $priceStr = substr($priceStr, 0, $size-1);
            $priceStr .= ')';
        }
        
        // for filtering rooms
        if (isset($_GET['rooms'])) {
            // generate the where statement for pickups
            $roomsStr = 'rooms IN(';
            for ($i = 0; $i < sizeof($_GET['rooms']); $i++)
                $roomsStr .= '\'' . $_GET['rooms'][$i] . '\',';

            // remove comma
            $size = strlen($roomsStr);
            if (substr($roomsStr, $size-1, 1) == ',')
                $roomsStr = substr($roomsStr, 0, $size-1);
            $roomsStr .= ')';
        }

        // completing the sql query
        $strArray = array($ratingStr, $priceStr, $roomsStr);
        for ($j = 0; $j < sizeof($strArray); $j++) {
          if ($strArray[$j] != '')
            $sql .= " AND " . $strArray[$j];
        }

        // get the filtered destinations
        $destinations = $connection->query($sql);
        while($row = $destinations->fetch_assoc()) {
            $name = $row['Name'];
            $description = $row['Description'];
            $image = $row ['Image'];
            $price = $row ['Price'];
            $id = $row ['ID'];
            $rating = $row ['Rating'];
			$room = $row ['Rooms'];
?>
       <div class='col-sm-3 col-md-3'>
				<div class='single-service wow slideInUp'>
                <img style="height:150px ;width=150px;" src="<?= $image; ?>">
                <div class="card-body">
                <div class="card-img-top">
                    <h6 style="margin-top:10px; margin-bottom:15px;" class="text-light bg-info text-center rounded p-1"><?= $name;?> (<?= $room; ?>)</h6>
                </div>
                <h4 style="color:blue;">Rating: <?= number_format((double)$rating,1,'.',''); ?> Star/s</h4>
                <p>
                    Price: RM<?= $price; ?>.00<br>
                </p>
				
				<a href="details.php?action=1&id=<?php echo $id ?>" class='btn btn-dark btn-primary btn-sm btn-book'>View</a>
				</div>
			</div>
		</div>
				  





<?php
        }
		
    }

?>
</div>
</div>
</div>
</div>
</div>


<?php
    // close connection
    $connection->close();

    include('footer.html');
?>