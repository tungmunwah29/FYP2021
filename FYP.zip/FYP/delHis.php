<?php 
	//Connect mySQL
			$con = mysqli_connect('localhost','root','','places');
		
		//Select Database
			mysqli_select_db($con, 'view');
		
		//Select Query
			$sql = "DELETE FROM view WHERE orderID = ".$_POST['orderID'].";";
		
		//Execute Query
			if(mysqli_query($con,$sql))
				header("refresh:1; url=history.php");
			else
				echo "Not Deleted";
?>