<?php
 session_start();
if(isset($_SESSION['status'])){
	if($_SESSION['status'] == true)	
		include('headerCustomer.php');
	else
	include('header.php');
}
else
	include('header.php');
 
 ?>

<?php

if (empty($_POST['name'])) {

// display error message (Name is empty)
echo "<script type='text/javascript'>
alert('Error: Please enter the  Name.');
history.go(-1);
</script>";
}
else if (empty($_POST['rating'])) {

// display error message (Name is empty)
echo "<script type='text/javascript'>
alert('Error: Please rate.');
history.go(-1);
</script>";
}
else if (empty($_POST['hotel_ID'])) {

echo "<script type='text/javascript'>
alert('Error: Please do not touch anything on the Hotel ID.');
history.go(-1);
</script>";
}
else if (isset ($_POST['message']) == false || empty($_POST['message'])) {

// display error message (Price is empty)
echo "<script type='text/javascript'>
alert('Error: Please enter the message.');
history.go(-1);
</script>";
}



else{

//Connect mySQL
$connection = mysqli_connect('localhost','root','','places');

//Select Database
mysqli_select_db($connection, 'rating');

$name = $_POST["name"];
$rating = $_POST["rating"];
$message = $_POST["message"];
$id = $_POST["hotel_ID"];


//Insert Query 
$sql = "INSERT INTO rating (Destination_ID,Names,Rate,Message)
 VALUES('$id','$name','$rating','$message');";

//Execute Query
$records = mysqli_query($connection,$sql);
echo '<script language="javascript">
alert("Data has been successfully uploaded");
window.location.replace("home.php");
</script>';
}
?>





