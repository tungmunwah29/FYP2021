-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2021 at 07:08 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `places`
--

-- --------------------------------------------------------

--
-- Table structure for table `destination`
--

CREATE TABLE `destination` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Category` varchar(30) NOT NULL,
  `Rooms` varchar(30) NOT NULL,
  `Price` double NOT NULL,
  `Profit` double NOT NULL,
  `Rating` int(10) NOT NULL,
  `StockBalance` int(30) NOT NULL,
  `Description` longtext NOT NULL,
  `Location` varchar(1000) NOT NULL,
  `Image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `destination`
--

INSERT INTO `destination` (`ID`, `Name`, `Category`, `Rooms`, `Price`, `Profit`, `Rating`, `StockBalance`, `Description`, `Location`, `Image`) VALUES
(1, 'test', 'Penang', 'Single Bedroom', 10, 50, 5, 4, 'testing 12345', 'https://stackoverflow.com/questions/18697927/get-database-from-xampp', 'images/12.jpg'),
(2, 'test', 'Penang', 'Double Bedroom', 50, 60, 4, 5, 'testing 12345', 'https://stackoverflow.com/questions/18697927/get-database-from-xampp', 'images/12.jpg'),
(3, 'test', 'Penang', 'Large Bedroom', 100, 5, 3, 5, 'testing 12345', 'https://stackoverflow.com/questions/18697927/get-database-from-xampp', 'images/12.jpg'),
(4, 'test 2 ', 'Penang', 'Single Bedroom', 10, 5, 2, 5, 'testing 12345', 'https://stackoverflow.com/questions/18697927/get-database-from-xampp', 'images/Perak.jpg'),
(5, 'test 2 ', 'Penang', 'Double Bedroom', 10, 5, 1, 5, 'testing 12345', 'https://stackoverflow.com/questions/18697927/get-database-from-xampp', 'images/12.jpg'),
(6, 'test 2 ', 'Perak', 'Double Bedroom', 10, 5, 5, 5, 'testing 12345', 'https://stackoverflow.com/questions/18697927/get-database-from-xampp', 'images/12.jpg'),
(9, 'testing', 'Negeri Sembilan', 'Single Bedroom', 10, 100, 5, 3, 'testing', 'https://www.facebook.com/', 'images/Sembilan.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `destination`
--
ALTER TABLE `destination`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `destination`
--
ALTER TABLE `destination`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
