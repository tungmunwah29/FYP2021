<?php 
	//Connect to MySQL
		$con = mysqli_connect('127.0.0.1','root','','places');
		
		//Select database
		mysqli_select_db($con,'destination');
		
		//Update query
		$sql = "UPDATE destination SET Name='".$_POST['name']."', 
		Category='".$_POST['category']."',
		Price= '".$_POST['price']."',
		Rooms='".$_POST['rooms']."',
		Profit='".$_POST['profit']."',
		StockBalance='".$_POST['stockBalance']."',
		Rating='".$_POST['rating']."',
		Description='".$_POST['description']."'
		WHERE ID = ".$_POST['ID'].";";
		
		

		
		
		//Execute the query
		if(mysqli_query($con, $sql))
			header("refresh:1,url=delete.php");
		else
			echo "Not Updated";
?>