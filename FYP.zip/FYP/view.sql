-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2021 at 07:08 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `places`
--

-- --------------------------------------------------------

--
-- Table structure for table `view`
--

CREATE TABLE `view` (
  `orderID` int(11) NOT NULL,
  `userID` varchar(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Category` varchar(20) NOT NULL,
  `Room` varchar(50) NOT NULL,
  `Price` decimal(4,0) NOT NULL,
  `Checkin` date DEFAULT NULL,
  `Checkout` date DEFAULT NULL,
  `Profit` decimal(4,0) NOT NULL,
  `Status` varchar(15) DEFAULT 'Pending',
  `Date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `view`
--

INSERT INTO `view` (`orderID`, `userID`, `Name`, `Category`, `Room`, `Price`, `Checkin`, `Checkout`, `Profit`, `Status`, `Date`) VALUES
(33, 'test1', 'test', 'Penang', 'Single Bedroom', '300', '2021-10-03', '2021-10-04', '500', 'Complete', '2021-10-18 14:08:55'),
(34, 'test2', 'test2', 'Penang', 'Single Bedroom', '200', '2021-10-03', '2021-10-04', '100', 'Pending', '2021-11-17 07:05:14'),
(56, 'testing', 'test', 'Penang', 'Single Bedroom', '10', '2021-10-24', '2021-10-25', '50', 'Pending', '2021-10-24 15:28:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `view`
--
ALTER TABLE `view`
  ADD PRIMARY KEY (`orderID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `view`
--
ALTER TABLE `view`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
