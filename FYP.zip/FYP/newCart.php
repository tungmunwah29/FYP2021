<?php
	session_start();
if(isset($_SESSION['status'])){
	if($_SESSION['status'] == true)	
		include('headerCustomer.php');
	else
	include('header.php');
}
else
	include('header.php');
?>

<?php
	
	//Connect mySQL
	$connection = mysqli_connect('127.0.0.1','root','','places');
			
	//Select Database
	mysqli_select_db($connection, 'places');
	
	function getIP(){
		$ip = $_SERVER['REMOTE_ADDR'];
				
		if(!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		}
		else if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		};
				
		return $ip;
	}
	
	if(isset($_SESSION['users'])){
		$userID = $_SESSION['users'];
		$id = "SELECT * FROM user WHERE UserID='$userID'";
		$run_id = mysqli_query($connection, $id);
		
		$user = mysqli_fetch_array($run_id);
		$userName = $user['UserID'];
	}
	
	if (isset($_POST['pro_ID'])){
		if(isset($_POST['Quantity'])){
				$ip = getIP();
				$pro_ID = $_POST['pro_ID'];
				$pro_quantity = $_POST['Quantity'];
				$pro_checkin = $_POST ['checkin'];
				$pro_checkout = $_POST ['checkout'];

		
				$check = "SELECT * FROM cart WHERE ID ='$pro_ID' AND ip_address='$ip'";
				$run_check = mysqli_query($connection, $check);
				
				$product =mysqli_fetch_array($run_check);
				
				if(mysqli_num_rows($run_check)==0){
					$insert = "INSERT into cart (ID,ip_address,quantity,checkin,checkout) values ('$pro_ID','$ip','$pro_quantity','$pro_checkin','$pro_checkout')";
					$run_insert = mysqli_query($connection, $insert);
					
					$sql = "SELECT * FROM destination WHERE ID = '$pro_ID'";
					$run_sql = mysqli_query($connection, $sql);
					$products = mysqli_fetch_array($run_sql);
					$quantity = $products['StockBalance'];
					$stockBalance = $quantity - $pro_quantity;
					$decrease = "UPDATE destination SET StockBalance = $stockBalance WHERE ID ='$pro_ID' ";
					$run_decrease = mysqli_query($connection, $decrease);

						
					echo"<script>window.open('newCart.php','_self')</script>";
				}else{
					if($pro_ID == $product['ID'] && $ip == $product['ip_address']){
						$quantity = $products['StockBalance'];
						$newQuantity = $pro_quantity;
						
						$increment = "UPDATE cart SET quantity = $newQuantity WHERE ID ='$pro_ID' AND ip_address='$ip'";
						$run_increment = mysqli_query($connection, $increment);
						$stockBalance = $quantity - $newQuantity;
						$decrease = "UPDATE destination SET StockBalance = $stockBalance WHERE ID ='$pro_ID'";
						$run_decrease = mysqli_query($connection, $decrease);
						//echo"<script>window.open('newCart.php','_self')</script>";
					}
					else{
						
						$insert = "INSERT into cart (ID,ip_address,quantity) values ('$pro_ID','$ip','$pro_quantity')";
						$run_insert = mysqli_query($connection, $insert);
						$stockBalance = $quantity - $pro_quantity;
						$decrease = "UPDATE destination SET StockBalance = $stockBalance WHERE ID ='$pro_ID'";
						$run_decrease = mysqli_query($connection, $decrease);
						echo"<script>window.open('newCart.php','_self')</script>";
						
					}
				}
			}		
		}
	
	

			
	
	if(isset($_GET['action'])){
		
		if(isset($_GET['id'])){
			if($_GET['action'] == 'delete')
			{
				if(isset($_GET['Quantity'])){
				$ip = getIP();
				$productID = $_GET['id'];
				$productQuantity = $_GET['Quantity'];
		
				$delete_product = "DELETE from cart where ID =$productID AND ip_address='$ip'";
				$run_delete_product = mysqli_query($connection, $delete_product);
				
				
					$sql = "SELECT * FROM destination WHERE ID = '$pro_ID'";
					$run_sql = mysqli_query($connection, $sql);
					$products = mysqli_fetch_array($run_sql);
					$quantity = $products['quantity'];
					$stockBalance = $quantity + $productQuantity;
					$increase = "UPDATE destination SET StockBalance = $stockBalance WHERE ID ='$pro_ID'";
					$run_increase = mysqli_query($connection, $increase);
			
				if($run_delete_product){
					echo"<script>window.open('newCart.php','_self')</script>";
				}
				}
			}
		}
	}
?>
	
<section id="service">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="service-area">
            <div class="title-area">
              <h2 class="tittle">Shopping Cart</h2>
              <span class="tittle-line"></span>	
              <p></p>
            </div>
			
			<!--Start of service content-->
			<div class="service-content">
				<table class="table table-bordered">
					<tr>
						<th width="20%">Item Name</th>
						<th width="20%">Image</th>
						<th width="10%">Category</th>
						<th width="10%">Types of Rooms</th>
						<th width="10%">Quantity</th>
						<th width="20%">Check in</th>
						<th width="20%">Check out</th>
						<th width="20%">Price</th>
						<th width="15%">Total</th>
						<th width="5%">Action</th>
					</tr>
					
					<?php 
						$total = 0;
						
						global $connection;
						
						$ip = getIP();
						$sel_price = "SELECT * FROM cart WHERE ip_address = '$ip'";
						$run_price = mysqli_query($connection, $sel_price);
						
						while($p_price=mysqli_fetch_array($run_price)){
							
							$pro_id = $p_price['ID'];
							$pro_quantity = $p_price['quantity'];
							$pro_checkin = $p_price['checkin'];
							$pro_checkout = $p_price['checkout'];

							
							$pro_price = "SELECT * from destination WHERE ID = '$pro_id'";
							$run_pro_price = mysqli_query($connection, $pro_price);
							
							while($pp_price=mysqli_fetch_array($run_pro_price)){
								
								$product_price = array($pp_price['Price']*$pro_quantity);
								$product_category = $pp_price['Category'];
								$product_room = $pp_price['Rooms'];
								$product_name = $pp_price['Name'];
								$product_image = $pp_price['Image'];
								$single_price =$pp_price['Price'];
								$product_profit = $pp_price['Profit'];
								$values = array_sum($product_price);
								$total += $values;
					?>
					<tr>
						<td width="20%"><?php echo $product_name ?></td>
						<td width="40%"><img src="<?php echo $product_image ?>"height='200' width='200'></td>
						<td width="20%"><?php echo $product_category ?></td>
						<td width="20%"><?php echo $product_room ?></td>
						<td width="10%"><?php echo $pro_quantity ?></td>
						<td width="10%"><?php echo $pro_checkin ?></td>
						<td width="10%"><?php echo $pro_checkout ?></td>

						<td width="20%"><?php echo "RM" . $single_price ?></td>
						<td width="15%"><?php echo "RM" . $single_price*$pro_quantity ?></td>
						<td><a href="newCart.php?action=delete&id= <?php echo $pro_id  ?>&Quantity= <?php echo $pro_quantity ?>"><span class="text-danger">Remove</span></a></td>
					</tr>
					<?php 	} 
						} 
					?>
					
					<tr align="right">
						<td colspan="5"><b>Sub Total: <?php echo"RM" . $total ?>  </b></td>
					</tr>
				</table>
				
				<div colspan="5">
					<a href= "home.php"><button data-text="Continue Shopping" class="button button-default"><span>Continue Shopping </span></button></a>
				</div>
				<form action="paypal.php" method="POST">
					<div colspan="5">
						<input type="hidden" value="<?php echo $product_name ?>" name="productName">
						<input type="hidden" value="<?php echo $userName ?>" name="userName">
						<input type="hidden" value="<?php echo $product_category ?>" name="productCategory">
						<input type="hidden" value="<?php echo $product_room?>" name="productRoom">
						<input type="hidden" value="<?php echo $values ?>" name="productPrice">
						
						<input type="hidden" value="<?php echo $pro_checkin ?>" name="productCheckin">
						<input type="hidden" value="<?php echo $pro_checkout ?>" name="productCheckout">
						<input type="hidden" value="<?php echo $product_profit?>" name="productProfit">

						
						<input type="hidden" value="<?php echo $total ?>" name="total">
						<button type='submit' data-text='CheckOut' class='button button-default'><span>Checkout</span></button>
					</div>
				</form>
			</div>
		</div>	
	</div>
</section>
<?php
include('footer.html');
?>