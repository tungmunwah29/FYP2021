<?php
 include('headerAdmin.php');
 
		//Connect mySQL
			$connection = mysqli_connect('localhost','root','','places');
		
		//Select Database
			mysqli_select_db($connection, 'places');
			
 ?>
  
 <?php
	
	$ID = $_POST['id'];
	$sql = "UPDATE view SET Status = 'Complete' WHERE orderID = ".$ID.";";

	if(mysqli_query($connection, $sql))
	header("refresh:1,url=viewOrder.php");
		else
	echo "Not Updated";
	?>